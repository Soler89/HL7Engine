﻿namespace Hl7Cloud.Module.Hl7Validate.Domain;

public class Class1
{

}
